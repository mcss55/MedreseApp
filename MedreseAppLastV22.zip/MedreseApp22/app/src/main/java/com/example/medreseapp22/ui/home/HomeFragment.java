package com.example.medreseapp22.ui.home;

import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.arch.lifecycle.ViewModelProvider;

import androidx.navigation.NavController;
import androidx.navigation.ui.AppBarConfiguration;

import com.example.medreseapp22.R;
import com.example.medreseapp22.databinding.FragmentHomeBinding;
import com.example.medreseapp22.ui.gallery.GalleryFragment;
import com.example.medreseapp22.ui.slideshow.SlideshowFragment;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    public BottomNavigationView bottomNavigationView;
    HomeFragment homeFragment=new HomeFragment();
    GalleryFragment galleryFragment=new GalleryFragment();
    SlideshowFragment slideshowFragment=new SlideshowFragment();
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this, new ViewModelProvider.NewInstanceFactory()).get(HomeViewModel.class);
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        final TextView textView = binding.textHome;
        homeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        bottomNavigationView=getActivity().findViewById(R.id.bottomNavigationView);

        return root;
    }
    public void replaceFragment(Fragment fragment){
        FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout,fragment);
        fragmentTransaction.commit();
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}