package com.mcss.medreseapp.ui.home;

import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.arch.lifecycle.ViewModelProvider;

import com.mcss.medreseapp.DrawerActivity;
import com.mcss.medreseapp.R;
import com.mcss.medreseapp.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment  {

    private FragmentHomeBinding binding;
    private DrawerActivity drawerActivity;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        DrawerLayout drawerLayout=getActivity().findViewById(R.id.drawer_layout);
        NavigationView navigationView=getActivity().findViewById(R.id.nav_view);
        View myView=inflater.inflate(R.layout.fragment_home,null,false);
        drawerLayout.addView(myView,0);
        HomeViewModel homeViewModel =
                new ViewModelProvider(this, new ViewModelProvider
                        .NewInstanceFactory())
                        .get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}